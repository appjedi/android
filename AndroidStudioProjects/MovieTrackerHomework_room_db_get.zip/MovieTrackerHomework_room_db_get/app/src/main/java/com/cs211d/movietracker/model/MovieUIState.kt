package com.cs211d.movietracker.model

data class MovieUIState(
    // Entree Selection
    val movie: MovieItem.MovieEntry? = null,
)